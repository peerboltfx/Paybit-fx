const btnCopy=document.getElementById('btnCopy');
const btnFile=document.getElementById('referral');

btnCopy.onclick= function(){
    btnFile.select();

    document.execCommand('Copy');
}

let loader=document.getElementById('loader');
function onload(){

}

 