require('./bootstrap');

require('alpinejs');

import aos from 'aos';

Aos.init(
    {
        duration:1000,
    }
)