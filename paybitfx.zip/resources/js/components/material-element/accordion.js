import React, { useEffect} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Aos from 'aos';
import "aos/dist/aos.css";

const useStyles = makeStyles((theme) => ({
  root: {
    width: '100%',
    marginTop:'7rem',
   
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '33.33%',
    flexShrink: 0,
    color:'white',
    
  },
  headings: {
    fontSize: theme.typography.pxToRem(15),
    color:'white',
    textAlign: 'center',
    
  },
  secondaryHeading: {
    fontSize: theme.typography.pxToRem(15),
    color: theme.palette.text.secondary,
  },
  typogrpah:{
      background:' rgb(100, 0, 167)',
      padding:'1rem',
      color: 'white',
  },

  h2:{
    textAlign:'center',
     color:'rgb(235, 136, 23)',
     marginBottom:'1rem',
  },
  pheading:{
    textAlign:'center',
     color:'black',
     marginBottom:'1rem',
     fontWeight:'400',
     marginLeft:'7%',
     marginRight: '7%',
  },
  container:{
      marginBottom:'3rem',
  }
}));

export default function ControlledAccordions() {
  const classes = useStyles();
  const [expanded, setExpanded] = React.useState(false);

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  useEffect(() => {
    Aos.init({duration: 2000});  
}, [])

  return (
<div id="services" className="cards-2">
             <div data-aos="zoom-in-right" className={classes.container}>
         <h2 className={classes.h2}>FAQs</h2>
        <b className={classes.pheading}>Out of in-experience in our investment system, we have a couple of questions our investors ask us.</b>
         </div>
         <div  data-aos="fade-up" >
      <Accordion expanded={expanded === 'panel1'} onChange={handleChange('panel1')}>
        <AccordionSummary
        className={classes.typogrpah}
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1bh-content"
          id="panel1bh-header"
        >
          <Typography className={classes.heading}>When can i deposit/withdraw from my investment account</Typography>
        </AccordionSummary>
        <AccordionDetails  className={classes.typogrpah}>
          <Typography className={classes.headings}>
          Deposit and withdrawal are available for at any time. Be sure, that your funds are not used in any ongoing trade before the withdrawal. The available amount is shown in your dashboard on the main page of Investing platform. Deposit and withdrawal are available for at any time. Be sure, that your funds are not used in any ongoing trade before the withdrawal. The available amount is shown in your dashboard on the main page of Investing platform.
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion className={classes.heading} expanded={expanded === 'panel2'} onChange={handleChange('panel2')}>
        <AccordionSummary
         className={classes.typogrpah}
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2bh-content"
          id="panel2bh-header"
        >
          <Typography className={classes.heading}>How can i check my account balance</Typography>
         
        </AccordionSummary>
        <AccordionDetails  className={classes.typogrpah}>
          <Typography className={classes.headings}>
          You can see this anytime on your accounts dashboard, Or any other page on the user account.

          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion expanded={expanded === 'panel3'} onChange={handleChange('panel3')}>
        <AccordionSummary
         className={classes.typogrpah}
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3bh-content"
          id="panel3bh-header"
        >
          <Typography className={classes.heading}>Can I cancel at anytime?</Typography>
         
        </AccordionSummary>
        <AccordionDetails  className={classes.typogrpah}>
          <Typography className={classes.headings}>
          Yes, you can cancel anytime no questions are asked when you cancel, but we would highly appreciate if you will give us some feedback.
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion expanded={expanded === 'panel4'} onChange={handleChange('panel4')}>
        <AccordionSummary
         className={classes.typogrpah}
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel4bh-content"
          id="panel4bh-header"
        >
          <Typography className={classes.heading}>How secure is my account data?</Typography>
        </AccordionSummary>
        <AccordionDetails  className={classes.typogrpah}>
          <Typography className={classes.headings}>
          Protecting the data you trust to us is our first priority. This part is really crucial in keeping the project in line to completion.
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion expanded={expanded === 'panel5'} onChange={handleChange('panel5')}>
        <AccordionSummary
        className={classes.typogrpah}
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel5bh-content"
          id="panel5bh-header"
        >
          <Typography className={classes.heading}>Can i have more than one account?</Typography>
        </AccordionSummary>
        <AccordionDetails  className={classes.typogrpah}>
          <Typography className={classes.headings}>
          You can create 3 (three) separate accounts from your computer and your IP address for protection against DDoS attacks.          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion xpanded={expanded === 'panel6'} onChange={handleChange('panel6')}>
        <AccordionSummary
        className={classes.typogrpah}
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel6bh-content"
          id="panel6bh-header"
        >
          <Typography className={classes.heading}>Any limits for an investment amount?</Typography>
        </AccordionSummary>
        <AccordionDetails  className={classes.typogrpah}>
          <Typography className={classes.headings}>
          The minimal investment amount is only $500 and the maximal amount is $500,000 if you wish to invest more please contact support
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion expanded={expanded === 'panel7'} onChange={handleChange('panel7')}>
        <AccordionSummary
        className={classes.typogrpah}
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel7bh-content"
          id="panel7bh-header"
        >
          <Typography className={classes.heading}>Who manages the investment portfolio?</Typography>
        </AccordionSummary>
        <AccordionDetails  className={classes.typogrpah}>
          <Typography className={classes.headings}>
          The investments are managed by our team of financial specialists with strong experience in financial markets, cryptocurrency mining and trading.       </Typography>
        </AccordionDetails>
      </Accordion>
    </div>
    </div>
  );
}