import React, { useEffect} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Timeline from '@material-ui/lab/Timeline';
import TimelineItem from '@material-ui/lab/TimelineItem';
import TimelineSeparator from '@material-ui/lab/TimelineSeparator';
import TimelineConnector from '@material-ui/lab/TimelineConnector';
import TimelineContent from '@material-ui/lab/TimelineContent';
import TimelineOppositeContent from '@material-ui/lab/TimelineOppositeContent';
import TimelineDot from '@material-ui/lab/TimelineDot';
import PersonAddIcon from '@material-ui/icons/PersonAdd';
import AccountBalanceIcon from '@material-ui/icons/AccountBalance';
import MonetizationOnTwoToneIcon from '@material-ui/icons/MonetizationOnTwoTone';
import RepeatIcon from '@material-ui/icons/Repeat';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import '../../../css/stock.css';
import Aos from 'aos';
import "aos/dist/aos.css";
const useStyles = makeStyles((theme) => ({
  paper: {
    padding: '6px 16px',
  },
  heading:{
    color: 'blue',
  },
  secondaryTail: {
    backgroundColor: theme.palette.secondary.main,
  },
 
}));

export default function CustomizedTimeline() {
  const classes = useStyles();
  useEffect(() => {
    Aos.init({duration: 2000});  
}, [])


  return (
    <div className="container">

    <Timeline align="alternate">
      <TimelineItem>
      
        <TimelineSeparator>
          <TimelineDot>
            <PersonAddIcon />
          </TimelineDot>
          <TimelineConnector />
        </TimelineSeparator>
        <TimelineContent>
          <Paper 
         data-aos="fade-up"
         data-aos-easing="ease-in-back"
          elevation={0} className={classes.paper}>
            <Typography variant='h6' component="h1">
              <b className={classes.heading}>Fast Registration</b> <br/><br/>
               Our registration process is fast <br /><br /> you are just few steps away from joining us
            </Typography>
           
          </Paper>
        </TimelineContent>
      </TimelineItem>
      <TimelineItem>
        <TimelineOppositeContent>
        </TimelineOppositeContent>
        <TimelineSeparator>
          <TimelineDot color="primary">
            <AccountBalanceIcon />
          </TimelineDot>
          <TimelineConnector />
        </TimelineSeparator>
        <TimelineContent>
          <Paper 
          data-aos-easing="ease-in-back"
          data-aos="fade-up"
          elevation={0} className={classes.paper}>
            <Typography variant="h6" component="h1">
            <b  className={classes.heading}>Deposit</b> <br/><br/>

            Get to know how our investment plan<br /><br /> works, select a preferred amount and make your first deposit.
            </Typography>
           
          </Paper>
        </TimelineContent>
      </TimelineItem>
      <TimelineItem>
        <TimelineSeparator>
          <TimelineDot color="primary" variant="outlined">
            <MonetizationOnTwoToneIcon />
          </TimelineDot>
          <TimelineConnector className={classes.secondaryTail} />
        </TimelineSeparator>
        <TimelineContent>
          <Paper          data-aos="fade-up"
          data-aos-easing="ease-in-back"
 elevation={0} className={classes.paper}>
          <Typography variant="h6" component="h1">
            <b  className={classes.heading}>Withdraw</b> <br/><br/>

            Wait for You Investment to grow<br /><br /> When when your investment time is due<br />make a request for withdrawal.
            </Typography>
          </Paper>
        </TimelineContent>
      </TimelineItem>
      <TimelineItem>
        <TimelineSeparator>
          <TimelineDot color="secondary">
            <RepeatIcon />
          </TimelineDot>
        </TimelineSeparator>
        <TimelineContent>
          <Paper
          data-aos-easing="ease-in-back"
          data-aos="fade-up"
          elevation={0} className={classes.paper}>
          <Typography variant="h6" component="h1">
            <b className={classes.heading}>Repeat</b> <br/><br/>

            If you wish to continue<br /><br /> You can repeat the process<br />now get started already!.
            </Typography>
          </Paper>
        </TimelineContent>
      </TimelineItem>
    </Timeline>
    </div>
  );
}