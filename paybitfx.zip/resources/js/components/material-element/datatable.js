import React, { useEffect} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import '../../../css/stockprice.css';
import Aos from 'aos';


const useStyles = makeStyles({
  table: {
    minWidth: 'auto',
  },
  headup: {
      background: 'blue',
      color: 'white',
  }
});

function createData(name, calories, fat, carbs, protein) {
  return { name, calories, fat, carbs, protein };
}

const rows = [
  createData('Harr blunt', 159, '$ 150', 24, './images/btc.webp'),
  createData('Habidash', 237, '$ 1500', 37, "./images/ETH.webp"),
  createData('Eclastons', 262, '$ 500', 24, './images/btc.webp'),
  createData('mastotachs', 305, '$ 2,000', 67, './images/btc.webp'),
  createData('Gabandivochv', 356, '$ 1300', 49, './images/ETH.webp'),
  createData('Annastecia', 356, '$ 800', 49, './images/ETH.webp'),
  createData('Gideon', 356, '$ 4,000', 49, './images/litecoin.webp'),
  createData('Sabatour', 356, '$ 500', 49, './images/btc.webp'),

];

const rowss = [
    createData('Harrifat', 159, '$ 550', 24, './images/btc.webp'),
    createData('Stephen', 237, '$ 3500', 37, "./images/ETH.webp"),
    createData('Kennedy', 262, '$ 6,000', 24, './images/btc.webp'),
    createData('Heyclare', 305, '$ 5,080', 67, './images/ETH.webp'),
    createData('Gabandivochv', 356, '$ 1,300', 49, './images/ETH.webp'),
    createData('Annastecia', 356, '$ 500', 49, './images/btc.webp'),
    createData('Gideon', 356, '$ 2,500', 49, './images/litecoin.webp'),
    createData('Sabatour', 356, '$ 1,600', 49, './images/litecoin.webp'),
  
  ];

export default function BasicTable() {
  const classes = useStyles();

  useEffect(() => {
    Aos.init({duration: 3000});  
}, [])

  return (
      <div className="data-container">
          <div data-aos="zoom-in-right" className="data">
    <TableContainer component={Paper}>
      <Table className={classes.table} aria-label="simple table">
        <TableHead>
          <TableRow className={classes.headup}>
            <TableCell>Name</TableCell>
            <TableCell align="right">Amount</TableCell>
            <TableCell align="right">Wallet</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.name}>
              <TableCell component="th" scope="row">
                {row.name}
              </TableCell>
              <TableCell align="right">{row.fat}</TableCell>
              <TableCell align="right"><img className='Images-cont' src={row.protein}  width='20px'/></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer></div>
    <div data-aos="zoom-in-left" className="data">
    <TableContainer component={Paper}>
      <Table className={classes.table} aria-label="simple table">
        <TableHead>
          <TableRow className={classes.headup}>
            <TableCell>Name</TableCell>
            <TableCell align="right">Amount</TableCell>
            <TableCell align="right">Wallet</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rowss.map((row) => (
            <TableRow key={row.name}>
              <TableCell component="th" scope="row">
                {row.name}
              </TableCell>
              <TableCell align="right">{row.fat}</TableCell>
              <TableCell align="right"><img className='Images-cont' src={row.protein}  width='20px'/></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer></div>
    </div>
  );
}