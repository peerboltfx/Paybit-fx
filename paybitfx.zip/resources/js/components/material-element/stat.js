import React, { PureComponent } from 'react';
import {
  LineChart, Line, XAxis, YAxis,ZAxis ,  CartesianGrid, Tooltip, Legend,
} from 'recharts';
import { makeStyles } from '@material-ui/core/styles';
import '../../../css/stock.css';



const data = [
  
  {
    name: 'Jun', BTC: 2390, ETH: 3800, LTE: 0, amt: 2500,
  },
  {
    name: 'Jul', BTC: 3490, ETH: 4300, LTE: 1000, amt: 2100,
  },
  {
    name: 'Aug', BTC: 5090, ETH: 5300, LTE: 2000, amt: 4100,
  },
  {
    name: 'Sept', BTC: 5490, ETH: 4300, LTE: 0, amt: 2100,
  },
  {
    name: 'Oct', BTC: 6490, ETH: 4800, LTE: 500, amt: 5100,
  },
  {
    name: 'Nov', BTC: 6990, ETH: 5300, LTE: 0, amt: 5690,
  },
  {
    name: 'Dec', BTC: 7490, ETH: 7300, LTE: 600, amt: 7100,
  },
  {
    name: 'Jan', BTC: 10490, ETH: 4300, LTE: 1000, amt: 9100,
  },
];

const useStyles = makeStyles((theme) => ({
    root: {
        width: '500',
        marginTop:'7rem',
       
      },
    paper: {
      padding: '6px 16px',
    },
    h2:{
        textAlign:'center',
         color:'rgb(235, 136, 23)',
         marginBottom:'1rem',
      },
      pheading:{
        textAlign:'center',
         color:'black',
         marginBottom:'1rem',
         fontWeight:'400',
         marginLeft:'7%',
         marginRight: '7%',
      },
      container:{
          marginBottom:'3rem',
         
      }
   
  }));

export default function Statistics () {


 
    const classes = useStyles();
    return (
        
        <div id="services" class="cards-2">
                 <div className={classes.container}>
         <h2 className={classes.h2}>Company Statistics</h2>
        <p className={classes.pheading}>We keep a clear record of our Financial Statistics, right from the beginning of our investment.</p>
         </div>
            <div>
      <LineChart
        width={700}
        height={400}
        data={data}
        margin={{
          top: 5, right: 30, left: 0, bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <ZAxis />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="BTC" stroke="#8884d8" activeDot={{ r: 8 }} />
        <Line type="monotone" dataKey="ETH" stroke="#82ca9d" />
      </LineChart></div></div>
    );
  
}
