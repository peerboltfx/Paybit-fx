<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
    <div class="container">
        <div class="col-lg-12">
            <div class="row">
            <div class="card">
        <div class="card-body">
            <div class="card-list">
                <div class="card-item">Username :</div>
                <div class="card-item"><?php echo e((auth()->user()->name)); ?></div>
                </div>
                <div class="card-list">
                    <div class="card-item">Reg Date :</div>
                    <div class="card-item"><?php echo e((auth()->user()->created_at->diffForHumans())); ?></div>
                </div>
                <div class="card-list">
                    <div class="card-item">Email</div>
                    <div class="card-item"><?php echo e((auth()->user()->email)); ?></div>
                </div>
                <div class="card-list">
                    <div class="card-item">Phone</div>
                    <div class="card-item"><?php echo e((auth()->user()->profile->phone) ?? ('NULL')); ?></div>
                </div>
                <div class="card-list">
                    <div class="card-item">Reg Date :</div>
                    <div class="card-item"><?php echo e((auth()->user()->created_at->diffForHumans())); ?></div>
                </div>
                <div class="card-list">
                    <div class="card-item">Updation Date:</div>
                    <div class="card-item"><?php echo e((auth()->user()->updated_at->diffForHumans())); ?></div>
                </div>
            </div>
            </div>

            <div class="card">
        <div class="card-body">
            <div class="card-list">
                <div class="card-item">Firstname :</div>
                <div class="card-item"><?php echo e((auth()->user()->profile->firstname) ?? ('NULL')); ?></div>
                </div>
               <div class="card-list">
                <div class="card-item">Lastname :</div>
                <div class="card-item"><?php echo e((auth()->user()->profile->lastname) ?? ('NULL')); ?></div>
                </div>
                <div class="card-list">
                    <div class="card-item">Phone :</div>
                    <div class="card-item"><?php echo e((auth()->user()->created_at->diffForHumans())); ?></div>
                </div>
                <div class="card-list">
                    <div class="card-item">Country</div>
                    <div class="card-item"><?php echo e((auth()->user()->profile->country) ?? ('NULL')); ?></div>
                </div>
                <div class="card-list">
                    <div class="card-item">Phone</div>
                    <div class="card-item"><?php echo e((auth()->user()->profile->phone) ?? ('NULL')); ?></div>
                </div>
                <div class="card-list">
                    <div class="card-item">Updation Date:</div>
                    <?php if(!empty(auth()->user()->profile)): ?>
                    <div class="card-item"><?php echo e((auth()->user()->profile->created_at->diffForHumans())); ?></div>
                <?php endif; ?>
                </div>
            </div>
            </div>
            </div>
            </div>

     <?php $__env->endSlot(); ?>


   
                
         <?php $__env->slot('logo', null, []); ?> 
            update profile
     <?php $__env->endSlot(); ?>

        <!-- Validation Errors -->
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        <form method="POST" action="/update.user">
            <?php echo csrf_field(); ?>

            <!-- Name -->
            <div class="row">
        <div class="col-md-8">
    <div class="Plan-object">
            <div class="mt-4">
            <label for="Firstname">  Firstname</label>

                <input id="firstname" class="block mt-1 w-full plan-object-element" placeholder="10,000 USD" type="text" name="firstname"  value="<?php echo e((auth()->user()->profile->firstname) ?? ('')); ?>" />
            </div>
            <!-- Email Address -->
            <div class="mt-4">
            <label for="Lastname">  Lastname</label>

            <input id="lastname" class="block mt-1 w-full plan-object-element" placeholder="10,000 USD" type="text" name="lastname"  value="<?php echo e((auth()->user()->profile->lastname) ?? ('')); ?>"/>
            </div>

            <div class="mt-4">
            <label for="Phone">  Phone</label>

                <input id="phone" class="block mt-1 w-full  plan-object-element" type="text" name="phone" value="<?php echo e((auth()->user()->profile->phone) ?? ('')); ?>"  />
            </div>
            <div class="mt-4">
                 <label for="Country">  Country</label>
                 <input id="country" class="block mt-1 w-full  plan-object-element" type="text" name="country" value="<?php echo e((auth()->user()->profile->country) ?? ('')); ?>"  />
               
            </div>
            
            </div>
            
            </div>
            <div class="col-md-4">
    <div class="Plan-object">
            <div class="mt-4">
            <label for="Username">  Username</label>

                <input id="name" class="block mt-1 w-full plan-object-element" placeholder="10,000 USD" type="text" name="name" value="<?php echo e((auth()->user()->name) ?? ('')); ?>" />
            </div>
            <!-- Email Address -->
            <div class="mt-4">
            <label for="Email">  Email</label>

            <input id="email" class="block mt-1 w-full plan-object-element" placeholder="10,000 USD" type="text" name="email" value="<?php echo e((auth()->user()->email) ?? ('')); ?>" />
            </div>

            <div class="mt-4">
            <label for="Phone">  BTC Wallet Address</label>

                <input id="phone" class="block mt-1 w-full  plan-object-element" type="text" name="acc_id" value="<?php echo e((auth()->user()->acc_id) ?? ('')); ?>"  />
            </div>
            
            
            

           
            
            </div>
            <div class="flex items-center justify-end mt-4">
               

               <button class="btn btn--outline">
                   <?php echo e(__('update')); ?>

               </button>
           </div>
        </div>
        
        </form>
    
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xamppp\htdocs\php\paybitFx\resources\views/Pages/profile.blade.php ENDPATH**/ ?>