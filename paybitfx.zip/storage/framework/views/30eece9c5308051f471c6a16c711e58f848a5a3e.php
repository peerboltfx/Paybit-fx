 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
    <div class="headers"><h3>Balance</h3>
        <h2> <?php echo e((auth()->user()->validDeposit->currency) ?? ('USD')); ?> <?php echo e((auth()->user()->validDeposit->growth) ?? ('00.00')); ?></h2>
    </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
<div class="table-container">
<div class="transact-container">
<h1 style=' font-weight:600;font-size:20px; margin-top:2rem ; margin-bottom:2rem ;'>Deposited transaction</h1>
<hr style='margin-bottom:1rem;width:20%;height:4px;background: #8200dd;'>
<?php if(!empty($deposits)): ?>
<?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="contend mb-2" >
    <div class="element-<?php echo e(($deposit->status) ?? ('pending')); ?>">
        <ul>
            <li>id </li>
            <li>plan </li>
            <li>amount</li>
            <li>ACC ID</li>
            <li>time</li>
            <li>status</li>
        </ul>
    </div>
    
   
    <div class="true">
        
    <ul>
   
            <li><?php echo e(($deposit->id)); ?> </li>
            <li> <?php echo e(($deposit->plan)); ?></li>
            <li><?php echo e(($deposit->amount)); ?> <?php echo e((auth()->user()->TempDeposit->currency)); ?></li>
            <li><?php echo e(($deposit->acc_id)); ?></li>
            <li><?php echo e(($deposit->created_at->diffForHumans())); ?></li>
            <li><a href="/deposit/status/<?php echo e(($deposit->id)); ?>"> <?php echo e(($deposit->status)); ?></a> <?php if($deposit->status == 'recieved'): ?> 
            <?php echo e(($deposit->updated_at->diffForHumans())); ?>

            <?php endif; ?>
            </li>
         
           
         
        </ul>
    </div>
    <div class='proof'>
        <a href="/storage/<?php echo e((auth()->user()->TempDeposit->photo) ?? ('/')); ?>">Click to view your proof</a>
        </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</div>
               
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\xamppp\htdocs\php\paybitFx\resources\views//Pages/transaction.blade.php ENDPATH**/ ?>