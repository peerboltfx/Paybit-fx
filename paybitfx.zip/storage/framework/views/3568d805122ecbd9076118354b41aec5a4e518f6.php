 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
    <div class="header"><h3>INVESTMENT GROWTH</h3>
    </div>
     <?php $__env->endSlot(); ?>

    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
               
         <?php $__env->slot('logo'); ?> 
            <a href="/">
                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.application-logo','data' => ['class' => 'w-20 h-20 fill-current text-gray-500']]); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-20 h-20 fill-current text-gray-500']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </a>
         <?php $__env->endSlot(); ?>
                    <div class="table-container">
                    <table class="table table-stripe">
                        <tr class="tr">
                                <td>id</td>
                                <td>Name</td>
                                <td>Wallet Address</td>
                                <td>Withdraw</td>
                                <td>Time</td>
                                <td>status</td>
                                <td>Action</td>
                        </tr>
                        <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($user->status == 'pending'): ?>                       

                            <tr key="<?php echo e(($user->updated_at->diffForHumans())); ?>">
                                <td><?php echo e(($user->user->id)); ?></td>
                                <td><?php echo e(($user->user->name)); ?></td>
                                <td> <?php echo e(($user->wallet_addr)); ?></td>
                                <td> <?php echo e(($user->user->email)); ?></td>
                                <td><?php echo e(($user->currency)); ?> <?php echo e(($user->amount)); ?></td>
                                <td> <?php echo e(($user->updated_at->diffForHumans())); ?></td>
                                <td> <?php echo e(($user->status)); ?></td>
                                <td><a href="/ConfirmPay/<?php echo e(($user->id)); ?>">Confirm</a><a href="/CancelConfirm/<?php echo e(($user->id)); ?>">Cancel</a></td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
</table>
</div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\xamppp\htdocs\php\paybitFx\resources\views/Pages/payUsers.blade.php ENDPATH**/ ?>