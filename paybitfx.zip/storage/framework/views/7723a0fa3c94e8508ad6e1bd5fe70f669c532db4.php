<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
       
     <?php $__env->endSlot(); ?>

    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-card','data' => []]); ?>
<?php $component->withName('auth-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('logo', null, []); ?> 
            <a href="/">
            </a>
         <?php $__env->endSlot(); ?>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
        <!-- Validation Errors -->
        <div class="content-status first">

          <p class="p-heading">plan</p>
          <?php if($reciept->plan == 'Gold'): ?>
          <p class="h-body"><img src="<?php echo e(asset('/images/gold.png')); ?>" /></p>
          <?php elseif($reciept->plan == 'Silver'): ?>
          <p class="h-body"><img src="<?php echo e(asset('/images/Silver.png')); ?>" /></p>
          <?php elseif($reciept->plan =='Diamond'): ?>
          <p class="h-body"><img src="<?php echo e(asset('/images/Diamond.png')); ?>" /></p>
          <?php elseif($reciept->plan =='Platinum'): ?>
          <p class="h-body"><img src="<?php echo e(asset('/images/Platinum.png')); ?>" /></p>
            <?php endif; ?>
            <div class="status-content"><p>status</p><p  class="<?php echo e(($reciept->status)); ?>"><?php echo e(($reciept->status)); ?></p></div>
      </div>
      <div class="content-status">
          <p class="p-heading">Profit</p>
          <?php if($reciept->plan == 'Gold'): ?>
          <h1 class="h-body">10% For 24 hours</h1>
          <?php elseif($reciept->plan == 'Silver'): ?>
          <h1 class="h-body">15% For 24 hours</h1>
          <?php elseif($reciept->plan =='Diamond'): ?>
          <h1 class="h-body">30% For 48 hours</h1>
          <?php elseif($reciept->plan =='Platinum'): ?>
          <h1 class="h-body">100% For 48 hours</h1>
            <?php endif; ?>
      </div>

      <div class="content-status">
          <p class="p-heading color-red">send Exactly <?php echo e(($reciept->amount)); ?><?php echo e(($reciept->currency)); ?></p>
          <?php if($reciept->currency == 'BTC'): ?>
        <h1 style="font-size:16px;" class="h-body">BTC : <?php echo e(($Wallet->BTC)); ?></h1>
            <?php elseif($reciept->currency == 'ETH'): ?>
        <h1 style="font-size:16px;" class="h-body">ETH : <?php echo e(($Wallet->ETH)); ?></h1>
            <?php elseif($reciept->currency == 'LTC'): ?>
        <h1 style="font-size:16px;" class="h-body">LTC : <?php echo e(($Wallet->LTC)); ?></h1>
            <?php endif; ?>
      </div>
      <div class=" p-2">
          <img src="../images/pay.png" width='100%' alt="">
      </div>
      <div class="content-status">
          <p class="p-heading">Date</p>
          <h1 class="h-body"><?php echo e(($reciept->created_at->diffForHumans())); ?></h1>
      </div>
      <div class="content-status">
          <p class="p-heading">gateway</p>
          <h1 class="h-body"><?php echo e(($reciept->gateway)); ?></h1>
      </div>
      <div class="content-status">
          <p class="p-heading">Principal return</p>
          <h1 class="h-body">Yes</h1>
      </div>

      <div class="content-status">
         <form action="/uploadProof" enctype='multipart/form-data' method="post">
        
         <?php echo csrf_field(); ?>
    <input type="file" name="photo" id="photo">
         <button type='submit' class="btn btn-primary">Harsh key</button>
        </form>
        <?php if(session('status')): ?>
            <div class="mb-4 font-medium text-sm text-green-600">
                <?php echo e(session('status')); ?>

                <a href="/storage/<?php echo e((auth()->user()->TempDeposit->photo)); ?>"><img src="/storage/<?php echo e((auth()->user()->TempDeposit->photo)); ?>" alt="Proof" style='margin:1rem 5rem' width='100px'></a>
            </div>
        <?php endif; ?>
      </div>
      <div class="content-status">
           <h1 class="h-body"></h1>
           <?php if($reciept->status == 'pending'): ?>
           <p class="p-heading alert-warning">will only be valid in less than 24Hrs</p>
           <p class="p-heading alert-warning"><a href="/restart/<?php echo e(($reciept->id)); ?>" style="text-decoration:underline;">click</a> to restart process</p>
           <?php elseif($reciept->status == 'recieved'): ?>
           <p class="p-heading alert-success">Your payment has been verified and your investment approved.</p>
            <?php endif; ?>
           <a href="/transaction">proceed →</a>

      </div>
       <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
               
               </div>
           </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xamppp\htdocs\php\paybitFx\resources\views//Pages/reciept.blade.php ENDPATH**/ ?>