 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
    <div class="headers"><h3>INVESTMENT GROWTH</h3>
    </div>
     <?php $__env->endSlot(); ?>

    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
               
         <?php $__env->slot('logo'); ?> 
            <a href="/">
                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.application-logo','data' => ['class' => 'w-20 h-20 fill-current text-gray-500']]); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-20 h-20 fill-current text-gray-500']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </a>
         <?php $__env->endSlot(); ?>
                    <div class="table-container">
                    <table class="table table-stripe">
                        <tr class="tr">
                                <td>id</td>
                                <td>Deposited</td>
                                <td>Growth</td>
                                <td>time</td>
                                <td>action</td>
                        </tr>
                        <tbody>
                        <?php $__currentLoopData = $growth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($user->status == 'enabled'): ?>
                            <tr key="<?php echo e(($user->updated_at->diffForHumans())); ?>">
                                <td><?php echo e(($user->user_id)); ?></td>
                                <td><?php echo e(($user->currency)); ?> <?php echo e(($user->amount)); ?></td>
                                <td><?php echo e(($user->currency)); ?> <?php echo e(($user->growth)); ?></td>
                                <td> <?php echo e(($user->updated_at->diffForHumans())); ?></td>
                                <td><a href="/investment/<?php echo e(($user->id)); ?>">edit</a> <a href="/investment/delete/<?php echo e(($user->id)); ?>">delete</a></td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
</table>
</div>

               
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\xamppp\htdocs\php\paybitFx\resources\views/Pages/growing.blade.php ENDPATH**/ ?>