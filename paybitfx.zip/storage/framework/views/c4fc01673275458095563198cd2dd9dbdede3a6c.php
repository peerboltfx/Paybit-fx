<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
    <h2><a href="/dashboard">Home/</a>Deposit</h2>
    <div class="headers"><h3>Balance</h3>
        <h2><?php echo e((auth()->user()->validDeposit->currency) ?? ('USD')); ?> <?php echo e((auth()->user()->validDeposit->growth) ?? (' 00.00')); ?></h2>
    </div>
     <?php $__env->endSlot(); ?>

    <div class="">
                <div class="">
                <div>
         <?php $__env->slot('logo', null, []); ?> 
            <a href="/">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.application-logo','data' => ['class' => 'w-20 h-20 fill-current text-gray-500']]); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-20 h-20 fill-current text-gray-500']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </a>
         <?php $__env->endSlot(); ?>


        <!-- Validation Errors -->
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        <form method="POST" action="/transfer">
            <?php echo csrf_field(); ?>

            
            <div class="Plan-object">
               <input type="radio" name="plan" value='Bronze' class='radio' id="">
               <label for="Bronze">  10% after 24 Hours</label>
               <div class="plan-table">
                <table border='0'>
                    <tr>
                        <td>Plan</td>
                        <td>Spent Amount ($) </td>
                        <td>Profit (%)</td>
                    </tr>
                    <tr>
                        <td>Bronze Plan</td>
                        <td>$50.00 - $1000.00 </td>
                        <td>15.00</td>
                    </tr>
                </table>
                </div>
            </div>

            <div class="Plan-object">
               <input type="radio" name="plan" value='Gold' class='radio' id="">
               <label for="Gold">  15% after 24 Hours</label>
               <div class="plan-table">
                <table border='0'>
                    <tr>
                        <td>Plan</td>
                        <td>Spent Amount ($) </td>
                        <td>Profit (%)</td>
                    </tr>
                    <tr>
                        <td>Gold Plan</td>
                        <td>$500.00 - $5000.00 </td>
                        <td>15.00</td>
                    </tr>
                </table>
                </div>
            </div>

            <div class="Plan-object">
               <input type="radio" name="plan" value='Silver'class='radio' id="">
               <label for="Diamond">  30% after 48 Hours</label>
               <div class="plan-table">
                <table border='0'>
                    <tr>
                        <td>Plan</td>
                        <td>Spent Amount ($) </td>
                        <td>Profit (%)</td>
                    </tr>
                    <tr>
                        <td>Diamond Plan</td>
                        <td>$1000.00 - $50000.00 </td>
                        <td>20.00</td>
                    </tr>
                </table>
                </div>
            </div>

            <div class="Plan-object">
               <input type="radio" name="plan" value='Platinum' class='radio' id="">
               <label for="Platinum">  100% after 48 Hours</label>
               <div class="plan-table">
                <table border='0'>
                    <tr>
                        <td>Plan</td>
                        <td>Spent Amount ($) </td>
                        <td>Profit (%)</td>
                    </tr>
                    <tr>
                        <td>Platinum Plan</td>
                        <td>$50.00 - $1000.00 </td>
                        <td>100.00</td>
                    </tr>
                </table>
                </div>
            </div>

            <!-- Email Address -->
            <div class="Plan-object">
            <div class="row">

             <div class="col-lg-6" id="currency">
             <label for="Currency">  Currency</label>

            <select name="currency" class="block mt-1 w-full plan-object-element" id="plan">
            <option value="">CURRENCY</option>
            <option value="XRP">USD <img src="./images/euro.png" alt=""></option>
            <option value="BTC">BTC <img src="./images/btc.png" alt=""></option>
            <option value="ETH">ETH <img src="./images/ETH.webp" alt=""></option>
        </option>
</select>
</div>

            <div class="col-lg-6">
            <label for="Gateway">  Gateway</label>

                <select name="gateway" class="block mt-1  w-full  plan-object-element" id="gateway">
            <option value="">--select--</option>
            <option value="Perfect Money">Perfect Money</option>
            <option value="Coinbase">Coinbase</option>
            <option value="trustWallet">trustWallet</option>
            <option value="TRNX Wallet">TRNX Wallet</option>
            </select>
            </div> 
</div>   
    <div class="row">
            <div class="col-lg-6">
            <label for="Amount">  Amount</label>

                <input id="amount" class="block mt-1 w-full plan-object-element" placeholder="10,000 USD" type="text" name="amount" :value="old('amount')" required />
            </div>
            <div class="col-lg-6">
            <label for="Amount">  Wallet_Address</label>

                <input id="amount" class="block mt-1 w-full plan-object-element" placeholder="10,000 USD" type="text" name="acc_id" :value="old('acc_id')" required />
            </div>
     
            </div>
            <div class="flex items-center justify-end mt-4">
               
            <?php if(empty($deposit)): ?>
            <button class=" btn btn--outline" type="submit">proceed to checkout <span>→</span></button>
            <?php elseif($deposit->status == 'recieved'): ?>
            <button class="btn btn--outline" type="submit">proceed to checkout <span>→</span></button>
            <?php elseif($deposit->status == 'pending'): ?>
            <button class="btn btn--outline" disabled type="submit">proceed to checkout <span>→</span></button>
            <p style="color:white;text-shadow:0px 0px 20px red;"><a href="/depositStatus/<?php echo e(($deposit->id)); ?>">transaction</a> still in progress, Complete payment process if you wish to continue</p>
            <?php endif; ?>
            </div>
            </div>

        </form>
    </div>
               
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xamppp\htdocs\php\paybitFx\resources\views//Pages/deposit.blade.php ENDPATH**/ ?>