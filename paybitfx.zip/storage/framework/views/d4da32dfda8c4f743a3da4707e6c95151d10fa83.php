 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
    <h2><a href="/dashboard">Home/</a>Account</h2>
       <div class="headers"><h3>Balance</h3>
        <h2><?php echo e((auth()->user()->validDeposit->currency) ?? ('USD')); ?> <?php echo e((auth()->user()->validDeposit->growth) ?? (' 00.00')); ?></h2>
    </div>
     <?php $__env->endSlot(); ?>
    <div class="container">
   <div class="Account">
   <div class="col-lg-12">
   <div class="">
                    <div class="card-body">
                        <h4 class='head-h2'>Referral Link</h4>
                    <div class="referral-container"> <input type="text" value="https://paybitfx.com/referra/<?php echo e((auth()->user()->validDeposit->referral) ?? ('')); ?>" name="" id="referral"><div id="btnCopy"><img src="<?php echo e(asset('./images/copy.png')); ?>" width="" alt=""></div></div>
                    </div>
                   
                    </div>

            <div class="row entity">


                    <div class="card card-rep">
                        <Typography align='center' class='head-h2' gutterBottom variant="h2" component="h2">
                            Other Acc Details
                                </Typography>
                   
                    <div class="card-body">
                        <h4>Name</h4>
                            <?php echo e((auth()->user()->profile->firstname) ?? ('XXXXX')); ?>         <?php echo e((auth()->user()->profile->lastname) ?? ('XXXXX')); ?>

                    </div>
                        <div class="card-body">
                            <h4>Phone</h4>
                                <?php echo e((auth()->user()->phone) ?? ('XXXXX')); ?>

                        </div>
                        <div class="card-body">
                            <h4>Country</h4>
                                <?php echo e((auth()->user()->country) ?? ('XXXXX')); ?>

                        </div>
                    </div>


                    
                    <div class="card card-rep">
                        <Typography align='center' class='head-h2' gutterBottom variant="h2" component="h2">
                            Investment Details
                                </Typography>
                    <?php if(!empty(auth()->user()->validDeposit)): ?>
                    <div class="card-body">
                        <h4>Plan</h4>
                            <h3 align='center'><?php echo e((auth()->user()->validDeposit->plan)); ?></h3>
                    </div>
                        <div class="card-body">
                            <h4>Amount</h4>
                            <h3 align='center'><?php echo e((auth()->user()->validDeposit->amount)); ?></h3>
                        </div>
                        <div class="card-body">
                            <h4>Currency</h4>
                            <h3 align='center'><img src='./images/<?php echo e((auth()->user()->validDeposit->currency)); ?>.webp' class='currency' width='30px' /></h3>
                        </div>
                        <div class="card-body">
                            
                            <h3 class='text-sm'><?php echo e((auth()->user()->validDeposit->updated_at->diffForHumans())); ?></h3>
                        </div>
                        <?php else: ?>
                        <h4>No Deposit Yet!</h4>
                        <?php endif; ?>
                    </div>
                </div>
                </div>

            
    </div>
   
   <div class="row">
    <div class="col-lg-6">
    <Typography align='center' gutterBottom variant="h2" component="h2">
        
                           <b> Deposited </b>
                                </Typography>
        <table class="tablet table-stripe">
            <tr class='trow'>
                    <td>ID</td>
                    <td>Status</td>
                    <td>time</td>
                    <td>Amount</td>
                    <td>Wallet</td>

            </tr>
            <tbody>
            <?php $__currentLoopData = $using; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!empty($usage)): ?>
            <tr class='trow2' key="<?php echo e($usage->id); ?>">
            <td><?php echo e(($usage->id)); ?></td>
            <td><?php echo e(($usage->status)); ?></td>
            <td>  <?php echo e(($usage->updated_at->diffForHumans())); ?></td>
                <td><?php echo e(($usage->amount)); ?></td>
                <td><img  src='./images/<?php echo e(($usage->currency)); ?>.webp'  width='30px'/></td>


            </tr>
            <?php else: ?>
            <tr>
                <p>No Deposit Yet <a href="/Deposit">Click</a> to make your first deposit</p>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
           
        </table>
     
    </div>

   <div class="col-lg-6">
   <Typography align='center' gutterBottom variant="h2" component="h2">
                           <b> Withdrawal </b>
                                </Typography>
        <table class="tablet table-stripe">
            <tr class='trow'>
                    <td>Name</td>
                    <td>Amount</td>
                    <td>Wallet</td>

            </tr>
            <tbody>
            <?php $__currentLoopData = $using; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class='trow2' key=''>
                <td>Someone Withraw <?php echo e(($usage->created_at->diffForHumans())); ?></td>
                <td><?php echo e(($usage->amount)); ?></td>
                <td><img  src='./images/<?php echo e(($usage->currency)); ?>.webp'  width='30px'/></td>


            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
   </div>
   </div> <div class="data-link">

        </div>
   </div>
  
   </div>
     <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\xamppp\htdocs\php\paybitFx\resources\views//Pages/account.blade.php ENDPATH**/ ?>