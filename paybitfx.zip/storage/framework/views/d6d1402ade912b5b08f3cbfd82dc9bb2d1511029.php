 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
       <div class="headers"><h3>Balance</h3>
        <h2><?php echo e((auth()->user()->validDeposit->currency) ?? ('USD')); ?> <?php echo e((auth()->user()->validDeposit->growth) ?? (' 00.00')); ?></h2>
        <div class="container-dash"><ul><li><a href="/Deposit">Deposit <span><i class="fa fa-credit-card-alt" aria-hidden="true"></i></span></a></li><li><a href="/deposit">Withdraw <span><i class="fa fa-university" aria-hidden="true"></i></span></a></li></ul></div>
    </div>
     <?php $__env->endSlot(); ?>
    
    <div id="application"></div>

     <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\xamppp\htdocs\php\paybitFx\resources\views/Pages/account.blade.php ENDPATH**/ ?>