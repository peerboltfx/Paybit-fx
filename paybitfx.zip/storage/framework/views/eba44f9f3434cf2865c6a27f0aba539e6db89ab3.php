 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
    <div class="headers"><h3>Balance</h3>
        <h2><?php echo e((auth()->user()->validDeposit->currency) ?? ('USD')); ?> <?php echo e((auth()->user()->validDeposit->growth) ?? (' 00.00')); ?></h2>
        <div class="container-dash"><ul><li><a href="/Deposit">Deposit <span><i class="fa fa-credit-card-alt" aria-hidden="true"></i></span></a></li><li><a href="/deposit">Withdraw <span><i class="fa fa-university" aria-hidden="true"></i></span></a></li></ul></div>
    </div>
     <?php $__env->endSlot(); ?>

    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-card','data' => []]); ?>
<?php $component->withName('auth-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('logo'); ?> 
            <a href="/">
                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.application-logo','data' => ['class' => 'w-20 h-20 fill-current text-gray-500']]); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-20 h-20 fill-current text-gray-500']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </a>
         <?php $__env->endSlot(); ?>


        <!-- Validation Errors -->
         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

        <form method="POST" enctype='multipart/form-data' action="/PaY/Charge/<?php echo e(($user->id)); ?>">
         
            <?php echo csrf_field(); ?>
            
        <div>
          
        <div class="mt-4"> <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.label','data' => ['for' => 'Wallet_addr','value' => __('Report')]]); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'Wallet_addr','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Report'))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <p><?php echo e(($user->ChargesWarrant)); ?></p>
    </div>
    <div class="mt-4"> <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.label','data' => ['for' => 'Wallet_addr','value' => __('Charge')]]); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'Wallet_addr','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Charge'))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <div class="table-2">
                <div class='tr-2'>
                    <div class="table-id2">Account Name</div>
                    <div class="table-content"><?php echo e((auth()->user()->name)); ?></div>

                </div>
                
                <div class='tr-2'>
                    <div class="table-id">Investment Plan</div>
                    <div class="table-content"><?php echo e(($growth->plan)); ?></div>

                </div>
                <div class='tr-2'>
                    <div class="table-id2">Investment Amount</div>
                    <div class="table-content"><?php echo e(($growth->amount)); ?><?php echo e(($growth->currency)); ?></div>

                </div>
                <div class='tr-2'>
                    <div class="table-id">Transaction Currency</div>
                    <div class="table-content">USD/<?php echo e(($growth->currency)); ?></div>

                </div>
                <div class='tr-2'>
                    <div class="table-id2">Investment Duration</div>
                    <div class="table-content"><?php echo e(($growth->created_at->diffForHumans())); ?></div>

                </div>
                <div class='tr-2'>
                    <div class="table-id">Phone No.</div>
                    <div class="table-content"><?php echo e((auth()->user()->profiles->phone) ?? ('Null')); ?></div>

</div>
                <div class='tr-2'>
                    <div class="table-id2">Email</div>
                    <div class="table-content"><?php echo e((auth()->user()->email)); ?></div>

                </div>
                <div class='tr-2'>
                    <div class="table-id">Investment Status</div>
                    <div class="table-content"><?php echo e(($growth->status)); ?></div>

                </div>
                <div class='tr-2'>
                    <div class="table-id2">Withdrawal Amount</div>
                    <div class="table-content"><?php echo e((auth()->user()->withdrawal->amount)); ?><?php echo e(($growth->currency)); ?></div>

                </div>
                <div class='tr-2'>
                    <div class="table-id">Withdrawal Status</div>
                    <div class="table-content <?php echo e((auth()->user()->withdrawal->status)); ?>-user"><?php echo e((auth()->user()->withdrawal->status)); ?></div>
                </div>
                <div class='tr-2'>
                    <div class="table-id2"><?php echo e(($user->Reason)); ?></div>
                    <div class="table-content"> <?php echo e(($user->Charge)); ?> <?php echo e(($growth->currency)); ?></div>
                </div>
</div>
<p class='w-full mr-10 mt-1'>Send <?php echo e(($user->Charge)); ?> <?php echo e(($growth->currency)); ?> to This Pefect money Address. Click to copy </p>
<div class="referral-container"> <input type="text" value="<?php echo e(($user->Link)); ?>" name="" id="referral"><div id="btnCopy"><img src="<?php echo e(asset('./images/copy.png')); ?>" width="" alt=""></div></div>

    </div>
              
            <div class="mt-4">
                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.label','data' => ['for' => 'Wallet_id','value' => __('Wallet ID')]]); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'Wallet_id','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Wallet ID'))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
               
                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['id' => 'wallet_id','class' => 'block mt-1 w-full','placeholder' => '10,000 USD','type' => 'text','name' => 'wallet_id','value' => '','required' => true]]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'wallet_id','class' => 'block mt-1 w-full','placeholder' => '10,000 USD','type' => 'text','name' => 'wallet_id','value' => '','required' => true]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

            </div>

            <div class="mt-4">
                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.label','data' => ['for' => 'uploadproof','value' => __('upload proof')]]); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'uploadproof','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('upload proof'))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
               
                <input type="file" name="photo" id="photo">
            </div>

            
       
            <div class="mt-4">
            <button class="btn btn-primary" type="submit">Pay Charges</button>
            </div>
             <?php if(session('form')): ?>
             
            <div class="mb-4 mt-4 font-medium text-sm text-green-600">
                <?php echo e(session('form')); ?>

            </div>
            <?php endif; ?>
           
</div>
        </form>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
               
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\xamppp\htdocs\php\paybitFx\resources\views/Pages/Charges.blade.php ENDPATH**/ ?>